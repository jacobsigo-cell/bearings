# Bearings engineering vertical slice v0.3

This package implements the first governed Bearings traveler-intelligence vertical slice in React + TypeScript.

**Demonstration data:** All five gold records are engineering fixtures. Their hotel names, findings, dates, quotations, and example URLs are not published travel research and must not be used for trip planning.

## What is included

- Canonical runtime schemas with Zod.
- `LB-HOTEL-001` five-case gold-record fixture set.
- Crescent Bay Inn Property View.
- Finding, Entity State, Currency, Planning Impact, and Source Drawer presentation.
- Commercial content separated from intelligence content.
- Explicit API boundary with three outcomes only:
  - validated success
  - transport failure
  - invalid payload
- Neutral Application State rendering for transport/schema failures.
- Automated governance tests, including false-certainty rejection tests.

## Critical boundary rule

A failed request or invalid API payload is **never** converted into `PENDING_VERIFICATION`, `STATUS_UNCERTAIN`, `NOT_ASSESSED`, or any other canonical intelligence value.

`src/api/researchSetClient.ts` is the boundary between untrusted transport data and governed application data. Components receive `ResearchSetMember` / `Property` only after runtime validation succeeds.

## Gold records

The five launch fixtures are:

1. Crescent Bay Inn — `NO_ACCOMMODATION_VERIFIED`
2. Pacific Edge Hotel — `VERIFIED_ACCOMMODATION`
3. Montage Laguna Beach — `CONFLICTING_EVIDENCE`
4. Surf & Sand Resort — `PENDING_VERIFICATION` with zero EvidenceRecords
5. Hotel Laguna — `CLOSED_REDEVELOPMENT` + `NOT_APPLICABLE`

## Commands

```bash
npm install
npm test
npm run build
npm run dev
```

## Replacing the mock transport

In `src/App.tsx`, replace `requestGoldResearchSet()` with the real request implementation. Keep `loadResearchSet()` and `parseResearchSetPayload()` at the boundary so unvalidated JSON never reaches intelligence components.

## GitHub Pages preview deployment

This package is ready for GitHub Pages.

1. Create an empty GitHub repository, preferably named `bearings`.
2. Upload or push all files in this project to the repository's `main` branch.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment → Source**, choose **GitHub Actions**.
5. The included `.github/workflows/deploy-pages.yml` workflow will run the governance tests, build the Vite app, and deploy the `dist` output.
6. After the workflow succeeds, the preview URL will appear in the workflow deployment summary and in **Settings → Pages**.

The workflow intentionally runs `npm test` before deployment. A failing governance test blocks the preview deployment.
